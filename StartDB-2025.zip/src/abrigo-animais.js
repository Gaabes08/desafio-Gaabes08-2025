class AbrigoAnimais {

  encontraPessoas(brinquedosPessoa1, brinquedosPessoa2, ordemAnimais) {
  }
}

export { AbrigoAnimais as AbrigoAnimais };
